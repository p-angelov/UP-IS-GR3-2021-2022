#include <iostream>

using namespace std;

int main()
{
    int inputNum;
    int dividerCount;
    int sumDividers;
    int divider;

    cout << "Enter a number: ";
    cin >> inputNum;
    cout << "Enter number of dividers to be displayed: ";
    cin >> dividerCount;

    for (int i = 0; i <= k; i++)
    {
        inputNum % divider == 0;

    }

    return 0;
}